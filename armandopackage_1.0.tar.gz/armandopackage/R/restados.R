restados <-
function(x,y) {
  x - y
}
